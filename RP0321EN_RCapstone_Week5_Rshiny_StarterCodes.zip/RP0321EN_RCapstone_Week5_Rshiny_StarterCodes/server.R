library(shiny)
library(dplyr)
library(ggplot2)
library(plotly)
library(leaflet)
library(readr)
library(lubridate)

source("model_prediction.R")

shinyServer(function(input, output, session) {
  
  selected_cities <- read.csv("selected_cities.csv", stringsAsFactors = FALSE)
  names(selected_cities) <- tolower(names(selected_cities))
  
  if (!("city" %in% names(selected_cities))) {
    if ("city_ascii" %in% names(selected_cities)) {
      names(selected_cities)[names(selected_cities) == "city_ascii"] <- "city"
    } else if ("label" %in% names(selected_cities)) {
      names(selected_cities)[names(selected_cities) == "label"] <- "city"
    }
  }
  
  if (!("lng" %in% names(selected_cities))) {
    if ("long" %in% names(selected_cities)) {
      names(selected_cities)[names(selected_cities) == "long"] <- "lng"
    } else if ("longitude" %in% names(selected_cities)) {
      names(selected_cities)[names(selected_cities) == "longitude"] <- "lng"
    }
  }
  
  if (!("lat" %in% names(selected_cities))) {
    if ("latitude" %in% names(selected_cities)) {
      names(selected_cities)[names(selected_cities) == "latitude"] <- "lat"
    }
  }
  
  city_weather_bike_df <- get_weather_bike_data()
  names(city_weather_bike_df) <- tolower(names(city_weather_bike_df))
  
  if (!("lng" %in% names(city_weather_bike_df)) || !("lat" %in% names(city_weather_bike_df))) {
    city_weather_bike_df <- left_join(
      city_weather_bike_df,
      selected_cities[, c("city", "lng", "lat")],
      by = "city"
    )
  }
  
  if ("forecast_datetime" %in% names(city_weather_bike_df)) {
    city_weather_bike_df$forecast_datetime <- as.POSIXct(city_weather_bike_df$forecast_datetime)
  }
  
  cities_max_bike <- city_weather_bike_df %>%
    group_by(city) %>%
    summarise(
      max_bike_demand = max(rented_bike_count, na.rm = TRUE),
      lng = first(lng),
      lat = first(lat),
      .groups = "drop"
    )
  
  output$city_map <- renderLeaflet({
    leaflet(cities_max_bike) %>%
      addTiles() %>%
      addCircles(
        lng = ~lng,
        lat = ~lat,
        weight = 1,
        radius = ~max_bike_demand / 2,
        popup = ~paste0(city, "<br>Max predicted demand: ", round(max_bike_demand)),
        label = ~city
      )
  })
  
  selected_city_max <- reactive({
    if (input$city_dropdown == "All") {
      cities_max_bike
    } else {
      cities_max_bike[cities_max_bike$city == input$city_dropdown, ]
    }
  })
  
  selected_city_detail <- reactive({
    if (input$city_dropdown == "All") {
      city_weather_bike_df
    } else {
      city_weather_bike_df[city_weather_bike_df$city == input$city_dropdown, ]
    }
  })
  
  output$temp_trend <- renderPlot({
    df <- selected_city_detail()
    req(nrow(df) > 0)
    
    x_col <- if ("forecast_datetime" %in% names(df)) "forecast_datetime" else "hour"
    
    ggplot(df, aes_string(x = x_col, y = "temperature", color = "city", group = "city")) +
      geom_line(size = 1) +
      labs(
        title = "Temperature Trend",
        x = ifelse(x_col == "forecast_datetime", "Forecast Datetime", "Hour"),
        y = "Temperature"
      ) +
      theme_minimal()
  })
  
  output$bike_trend <- renderPlotly({
    df <- selected_city_detail()
    req(nrow(df) > 0)
    
    x_col <- if ("forecast_datetime" %in% names(df)) "forecast_datetime" else "hour"
    
    p <- ggplot(df, aes_string(x = x_col, y = "rented_bike_count", color = "city", group = "city")) +
      geom_line(size = 1) +
      labs(
        title = "Predicted Bike-sharing Demand Trend",
        x = ifelse(x_col == "forecast_datetime", "Forecast Datetime", "Hour"),
        y = "Predicted Bike Count"
      ) +
      theme_minimal()
    
    ggplotly(p)
  })
  
  output$humidity_corr <- renderPlot({
    df <- selected_city_detail()
    req(nrow(df) > 0)
    
    ggplot(df, aes(x = humidity, y = rented_bike_count, color = city)) +
      geom_point(alpha = 0.7) +
      geom_smooth(method = "lm", se = FALSE, size = 1) +
      labs(
        title = "Humidity vs Predicted Bike-sharing Demand",
        x = "Humidity",
        y = "Predicted Bike Count"
      ) +
      theme_minimal()
  })
  
  observeEvent(input$city_dropdown, {
    if (input$city_dropdown == "All") {
      leafletProxy("city_map", data = cities_max_bike) %>%
        clearShapes() %>%
        clearMarkers() %>%
        addCircles(
          lng = ~lng,
          lat = ~lat,
          weight = 1,
          radius = ~max_bike_demand / 2,
          popup = ~paste0(city, "<br>Max predicted demand: ", round(max_bike_demand)),
          label = ~city
        )
    } else {
      city_df <- selected_city_max()
      req(nrow(city_df) > 0)
      
      leafletProxy("city_map", data = city_df) %>%
        clearShapes() %>%
        clearMarkers() %>%
        setView(
          lng = city_df$lng[1],
          lat = city_df$lat[1],
          zoom = 9
        ) %>%
        addCircles(
          lng = ~lng,
          lat = ~lat,
          weight = 1,
          radius = ~max_bike_demand / 2,
          popup = ~paste0(city, "<br>Max predicted demand: ", round(max_bike_demand)),
          label = ~city
        )
    }
  })
  
})