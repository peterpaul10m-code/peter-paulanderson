library(shiny)
library(leaflet)
library(plotly)

shinyUI(fluidPage(
  titlePanel("Bike-sharing demand prediction app"),
  
  sidebarLayout(
    sidebarPanel(
      selectInput(
        inputId = "city_dropdown",
        label = "Select a city:",
        choices = c("All", "Seoul", "Suzhou", "London", "New York", "Paris"),
        selected = "All"
      )
    ),
    
    mainPanel(
      leafletOutput("city_map", height = 400),
      br(),
      plotOutput("temp_trend", height = 250),
      plotlyOutput("bike_trend", height = 250),
      plotOutput("humidity_corr", height = 250)
    )
  )
))